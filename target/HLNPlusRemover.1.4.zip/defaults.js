const defaults = {
    hidePlusArticles: true,
    hideAdvertisement: true,
    hideShop: true,
    hideFooter: true,
    compact: true,
    hideComments: false
};