const defaults = {
    hideShop: true,
    hideFooter: true,
    hideComments: false
};